<?php
// @env nothing
$I = new SkipGuy($scenario);
$I->wantTo('run something');
$I->expect('it will work');