<div class="buy">
    <a href="/" title="Chocolate Bar" class="button rounded shadowed large blue">
        <span>Buy Chocolate Bar</span>
    </a>
</div>