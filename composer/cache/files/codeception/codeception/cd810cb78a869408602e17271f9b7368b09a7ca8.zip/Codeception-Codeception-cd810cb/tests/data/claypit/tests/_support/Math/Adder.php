<?php

namespace Math;

class Adder
{
    public function perform($a, $b)
    {
        return $a + $b;
    }
}
