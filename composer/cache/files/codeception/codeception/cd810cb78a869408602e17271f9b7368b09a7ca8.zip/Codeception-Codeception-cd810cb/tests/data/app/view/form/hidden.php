<html>
<body>
<form action="/form/complex" method="POST">
    <input type="hidden" id="action" name="action" value="kill_people" />
    <input type="submit" value="Submit" />
</form>
</body>
</html>