<?php

namespace Step\Order;

class CanCantSteps extends \OrderGuy
{
    public function someStep()
    {
        // nothing in here...
    }
}
