<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Welcome!</title>
</head>
<body>
    <form method="POST" action="/form/example11">
        <input type="text" name="username">
        <input type="text" name="password">
        <button type="submit" name="submit" value="first">Login</button>
        <button type="submit" name="submit" value="second">Login</button>
        <button type="submit" name="submit" value="third">Login</button>
        <button type="submit" name="submit" value="fourth">Login</button>
        <button type="submit" name="submit" value="fifth">Login</button>
        <button type="submit" name="submit" value="sixth">Login</button>
    </form>
</body>
</html>