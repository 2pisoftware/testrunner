<?php
$I = new PowerGuy($scenario);
$I->wantTo('reveal my power');
$I->gotThePower();
