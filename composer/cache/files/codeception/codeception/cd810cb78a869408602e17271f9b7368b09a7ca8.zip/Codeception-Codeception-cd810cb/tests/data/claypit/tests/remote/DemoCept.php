<?php
$I = new OtherGuy($scenario);
$I->amOnPage('/');
$I->see('Welcome to test app');