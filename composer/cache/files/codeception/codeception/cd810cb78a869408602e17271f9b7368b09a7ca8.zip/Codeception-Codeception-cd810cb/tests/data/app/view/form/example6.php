<form action="/form/example6">
    <input id="radio_preset1" name="frequency" type="radio" value="week" >
    <input id="radio_preset2" name="frequency" type="radio" value="hour" checked="checked">
    <input id="radio_preset3" name="frequency" type="radio" value="day">
    <button type="submit">Submit</button>
</form>