<?php
// @group notorun
// @incomplete
$I = new SkipGuy($scenario);
$I->wantTo('make it incomplete');
